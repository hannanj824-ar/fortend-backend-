// Makes sure the request body has a non-empty "text" field
const validateTodo = (req, res, next) => {
  const text = req.body.text;

  if (!text || text.trim() === "") {
    return res.status(400).json({ message: "Todo text is required" });
  }

  next();
};

module.exports = validateTodo;
