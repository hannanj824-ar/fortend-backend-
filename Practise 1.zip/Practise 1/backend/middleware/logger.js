// Logs every request: method, URL and current time
const logger = (req, res, next) => {
  const time = new Date().toLocaleTimeString();
  console.log(`[${time}] ${req.method} ${req.url}`);
  next(); // pass control to the next middleware/route
};

module.exports = logger;
