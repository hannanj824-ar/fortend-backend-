const express = require("express");
const cors = require("cors");
const logger = require("./middleware/logger");
const validateTodo = require("./middleware/validateTodo");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use(logger); // runs for every request

// In-memory storage (data resets when server restarts)
let todos = [
  { id: 1, text: "Learn React" },
  { id: 2, text: "Learn Express" },
];
let nextId = 3;

// CREATE - add a new todo
app.post("/todos", validateTodo, (req, res) => {
  const newTodo = { id: nextId++, text: req.body.text };
  todos.push(newTodo);
  res.status(201).json(newTodo);
});

// READ - get all todos
app.get("/todos", (req, res) => {
  res.json(todos);
});

// UPDATE - edit a todo by id
app.put("/todos/:id", validateTodo, (req, res) => {
  const id = Number(req.params.id);
  const todo = todos.find((t) => t.id === id);

  if (!todo) {
    return res.status(404).json({ message: "Todo not found" });
  }

  todo.text = req.body.text;
  res.json(todo);
});

// DELETE - remove a todo by id
app.delete("/todos/:id", (req, res) => {
  const id = Number(req.params.id);
  todos = todos.filter((t) => t.id !== id);
  res.json({ message: "Todo deleted" });
});

app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});
